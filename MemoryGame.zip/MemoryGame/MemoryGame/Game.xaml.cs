﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MemoryGame
{
    /// <summary>
    /// Interaction logic for Game.xaml
    /// </summary>
    public partial class Game : Window
    {
        private DateTime startTime;
        public List<Button> buttons = new List<Button>();
        public List<int> szamok = new List<int>();
        public Game(int number)
        {
            InitializeComponent();
            startTime = DateTime.Now; // Kezdőidő beállítása
            SzamGeneralas(number);
            GridBeallitas(number);
            
        }
        public void GridBeallitas(int szam)
        {
            for (int C = 0; C < szam; C++) // ezt a poént levédetem
            {
                Racs.RowDefinitions.Add(new RowDefinition());
            }
            for (int i = 0; i < szam; i++)
            {
                Racs.ColumnDefinitions.Add(new ColumnDefinition());
            }
            Gombok(szam);
        }

        public void Gombok(int szam)
        {
            Random r = new Random();
            int n = szamok.Count;
            while (n > 1)
            {
                n--;
                int k = r.Next(n + 1);
                int value = szamok[k];
                szamok[k] = szamok[n];
                szamok[n] = value;
            }

            for (int sor = 0; sor < szam; sor++)
            {
                for (int oszlop = 0; oszlop < szam; oszlop++)
                {
                    Button button = new Button();
                    button.FontSize = 30;
                    button.Content = null;
                    Grid.SetRow(button, sor);
                    Grid.SetColumn(button, oszlop);
                    Racs.Children.Add(button);
                    buttons.Add(button);
                    button.Click += Button_Click;
                }
            }
        }

        public void SzamGeneralas(int szam)
        {
            for (int i = 1; i <= szam * szam / 2; i++)
            {
                szamok.Add(i);
                szamok.Add(i);
            }
        }

        private bool AllButtonsRevealed()
        {
            foreach (var button in buttons)
            {
                if (button.Content == null)
                {
                    return false;
                }
            }
            return true;
        }

        // A már kiválasztott gombok és indexeik nyomon követésére szolgáló listák
        private List<Button> selectedButtons = new List<Button>();
        private List<int> selectedIndexes = new List<int>();

        // Az előzőleg kattintott gombokat nyomon követő listák törlésére szolgáló metódus
        private void ClearSelected()
        {
            foreach (var button in selectedButtons)
            {
                button.Content = null;
            }
            selectedButtons.Clear();
            selectedIndexes.Clear();
        }

        private bool waiting = false;
        private async void Button_Click(object sender, RoutedEventArgs e)
        {

            if (waiting)
            {
                return;
            }

            Button clickedButton = sender as Button;
            int index = buttons.IndexOf(clickedButton);

            // Ha a kattintott gomb már kiválasztott
            if (selectedButtons.Contains(clickedButton))
            {
                return;
            }

            clickedButton.Content = szamok[index];
            selectedButtons.Add(clickedButton);
            selectedIndexes.Add(index);

            // Ha már két gomb van kiválasztva
            if (selectedButtons.Count == 2)
            {
                // Ellenőrizzük, hogy a két kiválasztott gomb tartalma megegyezik-e
                if (szamok[selectedIndexes[0]] == szamok[selectedIndexes[1]])
                {
                    // Ha igen, hagyjuk fent a tartalmukat
                    selectedButtons.Clear();
                    selectedIndexes.Clear();

                    // Ellenőrizzük, hogy minden gomb tartalma látható-e
                    if (AllButtonsRevealed())
                    {
                        // Ha minden gomb látható, megjelenítjük a párbeszédpanelt vagy felugró ablakot
                        TimeSpan elapsedTime = DateTime.Now - startTime;
                        string formattedTime = elapsedTime.ToString(@"hh\:mm\:ss");
                        MessageBoxResult result = MessageBox.Show($"Gratulálok!\nÖsszesen{formattedTime} másodpercet töltöttél memória fejlesztéssel!\nMindegyiknek megtaláltad a párját!\nSzeretnél új játékot játszani?", "Játék vége", MessageBoxButton.YesNo);

                        if (result == MessageBoxResult.No)
                        {
                            // Ha a felhasználó igen-t választja, akkor kilépünk
                            Application.Current.Shutdown();
                        }
                        else
                        {
                            // Ha a felhasználó nem a nemet választja, akkor visszatérünk a kezdőképernyőre
                            // Ide írd a kódodat, ami visszatér a kezdőképernyőre
                            this.Close();
                            MainWindow main = new MainWindow();
                            main.Show();
                        }
                    }
                }
                else
                {
                    // Ha nem egyeznek meg a tartalmak, várjunk egy rövid időt, majd takarjuk el a tartalmukat
                    waiting = true; // Várakozás kezdete
                    await Task.Delay(1000);
                    ClearSelected();
                    waiting = false; // Várakozás vége
                }
            }
        }
    }
}
