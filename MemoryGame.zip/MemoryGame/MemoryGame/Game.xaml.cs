﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MemoryGame
{
    /// <summary>
    /// Interaction logic for Game.xaml
    /// </summary>
    public partial class Game : Window
    {
        private DateTime startTime;
        public List<Button> buttons = new List<Button>();
        public List<int> szamok = new List<int>();
        private List<Button> foundPairs = new List<Button>();
        public Game(int number)
        {
            InitializeComponent();
            startTime = DateTime.Now;
            SzamGeneralas(number);
            GridBeallitas(number);
            
        }
        public void GridBeallitas(int szam)
        {
            for (int C = 0; C < szam; C++) // ezt a poént levédetem
            {
                Racs.RowDefinitions.Add(new RowDefinition());
            }
            for (int i = 0; i < szam; i++)
            {
                Racs.ColumnDefinitions.Add(new ColumnDefinition());
            }
            Gombok(szam);
        }

        public void Gombok(int szam)
        {
            Random r = new Random();
            int n = szamok.Count;
            while (n > 1)
            {
                n--;
                int k = r.Next(n + 1);
                int value = szamok[k];
                szamok[k] = szamok[n];
                szamok[n] = value;
            }

            for (int sor = 0; sor < szam; sor++)
            {
                for (int oszlop = 0; oszlop < szam; oszlop++)
                {
                    Button button = new Button();
                    button.FontSize = 30;
                    button.Content = null;
                    Grid.SetRow(button, sor);
                    Grid.SetColumn(button, oszlop);
                    Racs.Children.Add(button);
                    buttons.Add(button);
                    button.Click += Button_Click;
                }
            }
        }

        public void SzamGeneralas(int szam)
        {
            for (int i = 1; i <= szam * szam / 2; i++)
            {
                szamok.Add(i);
                szamok.Add(i);
            }
        }

        private bool AllButtonsRevealed()
        {
            foreach (var button in buttons)
            {
                if (button.Content == null)
                {
                    return false;
                }
            }
            return true;
        }
        private List<Button> selectedButtons = new List<Button>();
        private List<int> selectedIndexes = new List<int>();
        private void ClearSelected()
        {
            foreach (var button in selectedButtons)
            {
                button.Content = null;
            }
            selectedButtons.Clear();
            selectedIndexes.Clear();
        }

        private bool waiting = false;
        private async void Button_Click(object sender, RoutedEventArgs e)
        {

            if (waiting)
            {
                return;
            }

            Button clickedButton = sender as Button;
            int index = buttons.IndexOf(clickedButton);

            if (selectedButtons.Contains(clickedButton) || foundPairs.Contains(clickedButton))
            {
                return;
            }

            clickedButton.Content = szamok[index];
            selectedButtons.Add(clickedButton);
            selectedIndexes.Add(index);

            if (selectedButtons.Count == 2)
            {
                if (szamok[selectedIndexes[0]] == szamok[selectedIndexes[1]])
                {
                    foundPairs.AddRange(selectedButtons);
                    selectedButtons.Clear();
                    selectedIndexes.Clear();

                    if (AllButtonsRevealed())
                    {
                        TimeSpan elapsedTime = DateTime.Now - startTime;
                        string formattedTime = elapsedTime.ToString(@"hh\:mm\:ss");
                        MessageBoxResult result = MessageBox.Show($"Gratulálok!\nÖsszesen{formattedTime} másodpercet töltöttél memória fejlesztéssel!\nMindegyiknek megtaláltad a párját!\nSzeretnél új játékot játszani?", "Játék vége", MessageBoxButton.YesNo);

                        if (result == MessageBoxResult.No)
                        {
                            Application.Current.Shutdown();
                        }
                        else
                        {
                            this.Close();
                            MainWindow main = new MainWindow();
                            main.Show();
                        }
                    }
                }
                else
                {
                    waiting = true;
                    await Task.Delay(1000);
                    ClearSelected();
                    waiting = false;
                }
            }
        }
    }
}
